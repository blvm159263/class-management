package com.mockproject.service.interfaces;

public interface ITrainingProgramSyllabusService {
}
