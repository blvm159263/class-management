package com.mockproject.mapper;

import com.mockproject.dto.TrainingMaterialDTO;
import com.mockproject.entity.TrainingClass;
import com.mockproject.entity.TrainingMaterial;
import com.mockproject.entity.UnitDetail;
import com.mockproject.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface TrainingMaterialMapper {

    TrainingMaterialMapper INSTANCE = Mappers.getMapper(TrainingMaterialMapper.class);

    @Mapping(target = "userId", source = "user.id")
    @Mapping(target = "unitDetailId", source = "unitDetail.id")
    TrainingMaterialDTO toDTO(TrainingMaterial trainingMaterial);

    @Mapping(target = "user", source = "userId", qualifiedByName = "mapUser")
    @Mapping(target = "unitDetail", source = "unitDetailId", qualifiedByName = "mapUnitDetail")
    TrainingMaterial toEntity(TrainingMaterialDTO dto);


    @Named("mapUser")
    default User mapUser(long id) {
        User user = new User();
        user.setId(id);
        return user;
    }

    @Named("mapUnitDetail")
    default UnitDetail mapUnitDetail(long id) {
        UnitDetail unitDetail = new UnitDetail();
        unitDetail.setId(id);
        return unitDetail;
    }

}
